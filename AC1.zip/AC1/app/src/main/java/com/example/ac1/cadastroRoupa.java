package com.example.ac1;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class cadastroRoupa extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_roupa);

        // Capturar os elementos do layout
        EditText etNome = findViewById(R.id.etNome);
        EditText etIdade = findViewById(R.id.etIdade);
        EditText etUF = findViewById(R.id.etUF);
        EditText etCidade = findViewById(R.id.etCidade);
        EditText etTelefone = findViewById(R.id.etTelefone);
        EditText etEmail = findViewById(R.id.etEmail);
        RadioGroup rgTamanho = findViewById(R.id.rgTamanho);
        CheckBox cbVermelho = findViewById(R.id.cbVermelho);
        CheckBox cbAzul = findViewById(R.id.cbAzul);
        CheckBox cbVerde = findViewById(R.id.cbVerde);
        CheckBox cbPreto = findViewById(R.id.cbPreto);
        Button btnCadastrar = findViewById(R.id.btnCadastrar);
        TextView tvResultado = findViewById(R.id.tvResultado);

        // Configurar ação do botão "Cadastrar"
        btnCadastrar.setOnClickListener(v -> {
            // Coletar informações
            String nome = etNome.getText().toString();
            String idade = etIdade.getText().toString();
            String uf = etUF.getText().toString();
            String cidade = etCidade.getText().toString();
            String telefone = etTelefone.getText().toString();
            String email = etEmail.getText().toString();

            int selectedTamanhoId = rgTamanho.getCheckedRadioButtonId();
            RadioButton selectedTamanho = findViewById(selectedTamanhoId);
            String tamanho = selectedTamanho != null ? selectedTamanho.getText().toString() : "Não selecionado";

            StringBuilder coresPreferidas = new StringBuilder();
            if (cbVermelho.isChecked()) coresPreferidas.append("Vermelho ");
            if (cbAzul.isChecked()) coresPreferidas.append("Azul ");
            if (cbVerde.isChecked()) coresPreferidas.append("Verde ");
            if (cbPreto.isChecked()) coresPreferidas.append("Preto ");
            String resultado = "Nome: " + nome + "\n" +
                    "Idade: " + idade + "\n" +
                    "UF: " + uf + "\n" +
                    "Cidade: " + cidade + "\n" +
                    "Telefone: " + telefone + "\n" +
                    "Email: " + email + "\n" +
                    "Tamanho: " + tamanho + "\n" +
                    "Cores Preferidas: " + coresPreferidas.toString();

            tvResultado.setText(resultado);
        });
    }
}