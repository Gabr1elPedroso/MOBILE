package com.example.ac1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class user extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        EditText etNome = findViewById(R.id.etNome);
        EditText etIdade = findViewById(R.id.etIdade);
        Button btnVerificar = findViewById(R.id.btnVerificar);
        TextView tvResultado = findViewById(R.id.tvResultado);

        btnVerificar.setOnClickListener(v -> {
            String nome = etNome.getText().toString();
            String idadeStr = etIdade.getText().toString();
            if (!idadeStr.isEmpty()) {
                int idade = Integer.parseInt(idadeStr);
                if (idade >= 18) {
                    tvResultado.setText(nome + ", você é maior de idade.");
                } else {
                    tvResultado.setText(nome + ", você é menor de idade.");
                }
            } else {
                tvResultado.setText("Por favor, insira uma idade válida.");
            }
        });
    }
}