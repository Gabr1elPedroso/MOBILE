package com.example.ac1;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Botão para a Activity "user"
        Button btnUser = findViewById(R.id.btnExercicio1);
        btnUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, user.class);
                startActivity(intent);
            }
        });

        // Botão para a Activity "Calculadora"
        Button btnCalculadora = findViewById(R.id.btnExercicio2);
        btnCalculadora.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Calculadora.class);
                startActivity(intent);
            }
        });

        // Botão para a Activity "cadastroRoupa"
        Button btnCadastroRoupa = findViewById(R.id.btnExercicio3);
        btnCadastroRoupa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, cadastroRoupa.class);
                startActivity(intent);
            }
        });

        // Botão para a Activity "checkBox"
        Button btnCheckBox = findViewById(R.id.btnExercicio4);
        btnCheckBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, checkBox.class);
                startActivity(intent);
            }
        });

        // Botão para a Activity "Salvar"
        Button btnSalvar = findViewById(R.id.btnExercicio5);
        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Salvar.class);
                startActivity(intent);
            }
        });
    }
}
