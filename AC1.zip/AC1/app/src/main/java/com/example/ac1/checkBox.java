package com.example.ac1;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.CheckBox;

public class checkBox extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_box);

        EditText etNome = findViewById(R.id.etNome);
        Button btnGerar = findViewById(R.id.btnGerar);
        LinearLayout containerCheckBoxes = findViewById(R.id.containerCheckBoxes);

        btnGerar.setOnClickListener(v -> {

            containerCheckBoxes.removeAllViews();


            String nome = etNome.getText().toString();


            for (int i = 0; i < nome.length(); i++) {
                char letra = nome.charAt(i);
                CheckBox checkBox = new CheckBox(this);
                checkBox.setText(String.valueOf(letra));
                containerCheckBoxes.addView(checkBox);
            }
        });
    }
}
