package com.example.ac1;



import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Calculadora extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadora);

        EditText etNumero1 = findViewById(R.id.etNumero1);
        EditText etNumero2 = findViewById(R.id.etNumero2);
        Button btnAdicionar = findViewById(R.id.btnAdicionar);
        Button btnSubtrair = findViewById(R.id.btnSubtrair);
        Button btnMultiplicar = findViewById(R.id.btnMultiplicar);
        Button btnDividir = findViewById(R.id.btnDividir);
        TextView tvResultado = findViewById(R.id.tvResultado);

        btnAdicionar.setOnClickListener(v -> {
            double numero1 = Double.parseDouble(etNumero1.getText().toString());
            double numero2 = Double.parseDouble(etNumero2.getText().toString());
            double resultado = numero1 + numero2;
            tvResultado.setText("Resultado: " + resultado);
        });

        btnSubtrair.setOnClickListener(v -> {
            double numero1 = Double.parseDouble(etNumero1.getText().toString());
            double numero2 = Double.parseDouble(etNumero2.getText().toString());
            double resultado = numero1 - numero2;
            tvResultado.setText("Resultado: " + resultado);
        });

        btnMultiplicar.setOnClickListener(v -> {
            double numero1 = Double.parseDouble(etNumero1.getText().toString());
            double numero2 = Double.parseDouble(etNumero2.getText().toString());
            double resultado = numero1 * numero2;
            tvResultado.setText("Resultado: " + resultado);
        });

        btnDividir.setOnClickListener(v -> {
            double numero1 = Double.parseDouble(etNumero1.getText().toString());
            double numero2 = Double.parseDouble(etNumero2.getText().toString());
            if (numero2 != 0) {
                double resultado = numero1 / numero2;
                tvResultado.setText("Resultado: " + resultado);
            } else {
                tvResultado.setText("Erro: Divisão por zero!");
            }
        });
    }
}
